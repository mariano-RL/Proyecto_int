import React from 'react';
const Footer =(props)=>{
    return(
    <footer>
        <p>Derechos Reservados.</p>
    </footer>

);

}
export default Footer;