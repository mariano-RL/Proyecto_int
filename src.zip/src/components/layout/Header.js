import React from 'react';
const Header = (props) =>{
    return (
        <header>
            <div className="holder">
            <img src="1099923.jpg" width="500" alt="Transportes X"/>
            <h1>Transportes X</h1>
        </div>
        </header>)}
export default Header;