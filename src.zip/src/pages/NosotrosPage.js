import React from 'react';
const NosotrosPage = (props)=> {
    return (
        <main className="holder">
            <div className="historia">
                <h2>Historia</h2>
                <p>Lorem ipsum dolor sit, amet consecttur adipisicing elit.</p>
                <p>Ipsum dolor sit, amet consectur adpscasiucuiaaqcfwa </p>    
            </div>
            <div className="staff">
                <h2>Staff</h2>
                <div className="persona">
                <img src="dos hombres.jpg" width="500" alt="Socios"/>
                <h5>Juan gomez</h5>
                <h6>Gerente General</h6>
                <p>Lorem ipsum dolor sit amet,consectur adipisicng elit.</p>
                </div>
            </div>
            
        </main>
    );
}
export default NosotrosPage;